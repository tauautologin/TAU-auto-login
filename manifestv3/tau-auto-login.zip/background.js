self.addEventListener("install", () => {
  console.log("TAU Auto Login Extension Installed (V3)");
});
